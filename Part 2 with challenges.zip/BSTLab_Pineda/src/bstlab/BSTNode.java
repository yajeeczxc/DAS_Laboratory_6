package bstlab;
 
public class BSTNode {
    int data;        // the value stored in this node
    BSTNode left;    // root of the left subtree (smaller values)
    BSTNode right;   // root of the right subtree (larger values)
 
    public BSTNode(int data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}
