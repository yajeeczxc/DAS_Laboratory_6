package bstlab;

import java.util.Queue;
import java.util.LinkedList;

public class BinarySearchTree {
 
    private BSTNode root;   // top of the tree
    private int size;       // number of nodes
 
    public BinarySearchTree() {
        root = null;
        size = 0;
    }
 
    public boolean isEmpty() {
        return root == null;
    }
 
    public int getSize() {
        return size;
    }
 
    public BSTNode getRoot() {
        return root;
    }
 
    public void clear() {
        root = null;
        size = 0;
    }

    /** Inserts a value. Returns false if the value already exists. */
    public boolean insert(int value) {
        if (root == null) {
            root = new BSTNode(value);
            size++;
            return true;
        }
        BSTNode current = root;
        while (true) {
            if (value == current.data) {
                return false;                   // duplicate: reject
            }
            if (value < current.data) {
                if (current.left == null) {
                    current.left = new BSTNode(value);
                    size++;
                    return true;
                }
                current = current.left;         // keep going left
            } else {
                if (current.right == null) {
                    current.right = new BSTNode(value);
                    size++;
                    return true;
                }
                current = current.right;        // keep going right
            }
        }
    }
 
    /** Returns the tree rotated 90 degrees: right subtree on top. */
    public String toSidewaysString() {
        StringBuilder sb = new StringBuilder();
        buildSideways(root, 0, sb);
        return sb.toString();
    }
 
    private void buildSideways(BSTNode node, int depth, StringBuilder sb) {
        if (node == null) {
            return;
        }
        buildSideways(node.right, depth + 1, sb);
        sb.append("    ".repeat(depth)).append(node.data).append("\n");
        buildSideways(node.left, depth + 1, sb);
    }
    
    public int getHeight() {
    return height(root);
}

    private int height(BSTNode node) {
        if (node == null) {
        return -1;
    }
    int leftHeight = height(node.left);
    int rightHeight = height(node.right);
    return 1 + Math.max(leftHeight, rightHeight);
    }

// ---------------- TRAVERSALS ----------------
 
    public String inorder() {                       // Left, Node, Right
        StringBuilder sb = new StringBuilder();
        inorder(root, sb);
        return sb.toString().trim();
    }
 
    private void inorder(BSTNode node, StringBuilder sb) {
        if (node == null) {
            return;                                 // base case
        }
        inorder(node.left, sb);
        sb.append(node.data).append(" ");           // visit
        inorder(node.right, sb);
    }
    public String preorder() {                      // Node, Left, Right
        StringBuilder sb = new StringBuilder();
        preorder(root, sb);
        return sb.toString().trim();
    }
 
    private void preorder(BSTNode node, StringBuilder sb) {
        if (node == null) {
            return;
        }
        sb.append(node.data).append(" ");           // visit FIRST
        preorder(node.left, sb);
        preorder(node.right, sb);
    }
 
    public String postorder() {                     // Left, Right, Node
        StringBuilder sb = new StringBuilder();
        postorder(root, sb);
        return sb.toString().trim();
    }
 
    private void postorder(BSTNode node, StringBuilder sb) {
        if (node == null) {
            return;
        }
        postorder(node.left, sb);
        postorder(node.right, sb);
        sb.append(node.data).append(" ");           // visit LAST
    }
    
    /** Returns the path taken to reach the value, or null if not found. */
    public String search(int value) {
        StringBuilder path = new StringBuilder();
        BSTNode current = root;
        while (current != null) {
            if (path.length() > 0) {
                path.append(" -> ");
            }
            path.append(current.data);
            if (value == current.data) {
                return path.toString();              // found
            }
            current = (value < current.data) ? current.left : current.right;
        }
        return null;                                 // fell off the tree
    }
    
    /** Deletes a value using the successor (default). Returns false if not found. */
public boolean delete(int value) {
    return delete(value, false);
}

/** Deletes a value. usePredecessor selects which neighbor replaces a two-child node. */
public boolean delete(int value, boolean usePredecessor) {
    if (search(value) == null) {
        return false;
    }
    root = deleteNode(root, value, usePredecessor);
    size--;
    return true;
}

private BSTNode deleteNode(BSTNode node, int value, boolean usePredecessor) {
    if (node == null) {
        return null;
    }
    if (value < node.data) {
        node.left = deleteNode(node.left, value, usePredecessor);
    } else if (value > node.data) {
        node.right = deleteNode(node.right, value, usePredecessor);
    } else {
        // Case 1: leaf
        if (node.left == null && node.right == null) {
            return null;
        }
        // Case 2: exactly one child
        if (node.left == null) {
            return node.right;
        }
        if (node.right == null) {
            return node.left;
        }
        // Case 3: two children
        if (usePredecessor) {
            BSTNode predecessor = findMax(node.left);
            node.data = predecessor.data;
            node.left = deleteNode(node.left, predecessor.data, usePredecessor);
        } else {
            BSTNode successor = findMin(node.right);
            node.data = successor.data;
            node.right = deleteNode(node.right, successor.data, usePredecessor);
        }
    }
    return node;
}
 
    private BSTNode findMin(BSTNode node) {
        while (node.left != null) {
            node = node.left;
        }
        return node;
    }
    
    private BSTNode findMax(BSTNode node) {
        while (node.right != null) {
            node = node.right;
        }
        return node;
}
    
    public Integer findMin() {
    if (root == null) {
        return null;
    }
    return findMin(root).data;
}

    public Integer findMax() {
    if (root == null) {
        return null;
    }
    BSTNode current = root;
    while (current.right != null) {
        current = current.right;
    }
    return current.data;
    }
    
    public String levelorder() {
    StringBuilder sb = new StringBuilder();
    if (root == null) {
        return "";
    }
    Queue<BSTNode> q = new LinkedList<>();
    q.add(root);
    while (!q.isEmpty()) {
        BSTNode node = q.poll();
        sb.append(node.data).append(" ");
        if (node.left != null) {
            q.add(node.left);
        }
        if (node.right != null) {
            q.add(node.right);
        }
    }
    return sb.toString().trim();
    }
}


