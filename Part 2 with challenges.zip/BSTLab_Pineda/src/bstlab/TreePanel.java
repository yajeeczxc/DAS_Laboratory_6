package bstlab;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.FontMetrics;
import java.util.HashMap;
import java.util.Map;

public class TreePanel extends JPanel {

    private BSTNode root;
    private static final int NODE_DIAMETER = 36;
    private static final int LEVEL_HEIGHT = 70;
    private static final int H_SPACING = 45;

    private final Map<BSTNode, Integer> xPos = new HashMap<>();
    private final Map<BSTNode, Integer> yPos = new HashMap<>();
    private int counter;

    public void setRoot(BSTNode root) {
        this.root = root;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (root == null) {
            return;
        }
        xPos.clear();
        yPos.clear();
        counter = 0;
        computePositions(root, 0);

        g.setColor(Color.BLACK);
        drawEdges(g, root);
        drawNodes(g, root);
    }

    private void computePositions(BSTNode node, int depth) {
        if (node == null) {
            return;
        }
        computePositions(node.left, depth + 1);
        xPos.put(node, counter * H_SPACING + NODE_DIAMETER);
        yPos.put(node, depth * LEVEL_HEIGHT + NODE_DIAMETER);
        counter++;
        computePositions(node.right, depth + 1);
    }

    private void drawEdges(Graphics g, BSTNode node) {
        if (node == null) {
            return;
        }
        int x1 = xPos.get(node);
        int y1 = yPos.get(node);
        if (node.left != null) {
            g.drawLine(x1, y1, xPos.get(node.left), yPos.get(node.left));
            drawEdges(g, node.left);
        }
        if (node.right != null) {
            g.drawLine(x1, y1, xPos.get(node.right), yPos.get(node.right));
            drawEdges(g, node.right);
        }
    }

    private void drawNodes(Graphics g, BSTNode node) {
        if (node == null) {
            return;
        }
        int x = xPos.get(node);
        int y = yPos.get(node);

        g.setColor(Color.WHITE);
        g.fillOval(x - NODE_DIAMETER / 2, y - NODE_DIAMETER / 2, NODE_DIAMETER, NODE_DIAMETER);
        g.setColor(Color.BLACK);
        g.drawOval(x - NODE_DIAMETER / 2, y - NODE_DIAMETER / 2, NODE_DIAMETER, NODE_DIAMETER);

        String text = String.valueOf(node.data);
        FontMetrics fm = g.getFontMetrics();
        int textX = x - fm.stringWidth(text) / 2;
        int textY = y + fm.getAscent() / 2 - 2;
        g.drawString(text, textX, textY);

        drawNodes(g, node.left);
        drawNodes(g, node.right);
    }
}
