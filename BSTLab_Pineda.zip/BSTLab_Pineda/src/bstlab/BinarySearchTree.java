package bstlab;
 
public class BinarySearchTree {
 
    private BSTNode root;   // top of the tree
    private int size;       // number of nodes
 
    public BinarySearchTree() {
        root = null;
        size = 0;
    }
 
    public boolean isEmpty() {
        return root == null;
    }
 
    public int getSize() {
        return size;
    }
 
    public BSTNode getRoot() {
        return root;
    }
 
    public void clear() {
        root = null;
        size = 0;
    }

    /** Inserts a value. Returns false if the value already exists. */
    public boolean insert(int value) {
        if (root == null) {
            root = new BSTNode(value);
            size++;
            return true;
        }
        BSTNode current = root;
        while (true) {
            if (value == current.data) {
                return false;                   // duplicate: reject
            }
            if (value < current.data) {
                if (current.left == null) {
                    current.left = new BSTNode(value);
                    size++;
                    return true;
                }
                current = current.left;         // keep going left
            } else {
                if (current.right == null) {
                    current.right = new BSTNode(value);
                    size++;
                    return true;
                }
                current = current.right;        // keep going right
            }
        }
    }
 
    /** Returns the tree rotated 90 degrees: right subtree on top. */
public String toSidewaysString() {
        StringBuilder sb = new StringBuilder();
        buildSideways(root, 0, sb);
        return sb.toString();
    }
 
    private void buildSideways(BSTNode node, int depth, StringBuilder sb) {
        if (node == null) {
            return;
        }
        buildSideways(node.right, depth + 1, sb);
        sb.append("    ".repeat(depth)).append(node.data).append("\n");
        buildSideways(node.left, depth + 1, sb);
    }
}
